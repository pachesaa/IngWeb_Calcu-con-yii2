<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "progreso".
 *
 * @property int $id
 * @property string $nombre
 * @property double $progreso1
 * @property double $progreso2
 */
class Progreso extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'progreso';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nombre', 'progreso1', 'progreso2'], 'required'],
            [['progreso1', 'progreso2'], 'number'],
            [['nombre'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nombre' => 'Nombre',
            'progreso1' => 'Progreso1',
            'progreso2' => 'Progreso2',
        ];
    }
}
