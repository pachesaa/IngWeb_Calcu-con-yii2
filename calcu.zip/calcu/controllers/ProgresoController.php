<?php

namespace app\controllers;

use Yii;
use app\models\Progreso;
use app\models\ProgresoSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * ProgresoController implements the CRUD actions for Progreso model.
 */
class ProgresoController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Progreso models.
     * @return mixed
     */

    public function actionIndex()
    {
        $searchModel = new ProgresoSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $datos = $dataProvider->query->all();
        $nuevos = [];
        
        foreach($datos as $key => $item){
            $aux =  new \stdClass();
            $aux->id = $item->id;
            $aux->nombre = $item->nombre;
            $aux->progreso1 = $item->progreso1;
            $aux->progreso2 = $item->progreso2;
            $aux->progreso3 = $this->calcular($item->progreso1,$item->progreso2);
            $nuevos[$item->id]=$aux;
        
        }
       

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'datos'=>$nuevos,
            
        ]);
    }

    private function calcular($nota1,$nota2){

        $calcu1=(($nota1*0.25)+($nota2*0.35));
        $calcu=(6-$calcu1)/0.40;

        return $calcu;
    }
    
    /**
     * Displays a single Progreso model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Progreso model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Progreso();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Progreso model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Progreso model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Progreso model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Progreso the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Progreso::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
