<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ProgresoSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Progresos';
$this->params['breadcrumbs'][] = $this->title;



?>
<div class="progreso-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Progreso', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <div class="table-responsive">
        <table class="table table-striped">
        <thead>
        <tr>
            <td>ID</td>
            <td>Nombre</td>
            <td>Nota 1</td>
            <td>Nota 2</td>
            <td>Nota 3</td>
            <td></td>
            
        </tr>
        </thead>
            <?php foreach($datos as $key => $item):?> 
            <tr>
                <td>
                <?=$item->id?>
                </td>
                <td>
                <?=$item->nombre?>
                </td>
                <td>
                <?=$item->progreso1?>
                </td>
                <td>
                <?=$item->progreso2?>
                </td>
                <td>
                <?=$item->progreso3?>
                </td>
                

              
            </tr>
            <?php endforeach;?>
        </table>
    </div>

</div>
