<?php

/* @var $this yii\web\View */

$this->title = 'calcu';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Calcular nota</h1>

        <p class="lead"></p>

        <p><a class="btn btn-lg btn-success" href="http://localhost/calcu/web/index.php?r=progreso%2Findex">nota 1 + nota 2</a></p>
    </div>

    </div>
